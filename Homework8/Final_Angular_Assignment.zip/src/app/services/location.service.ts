import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import {Observable} from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class LocationService {
  private BASE_URL = 'https://ipinfo.io/?token=65c38dc00ac738';
  private GOOGLE_MAPS_URL="https://maps.googleapis.com/maps/api/geocode/json?key=AIzaSyDGKIpymjRxuwfAYQKOQPKOQ4xcX9qyh4Q&address="

  constructor(private http: HttpClient) { }

  getLocation():Observable<any>{
    return this.http.get<any>(this.BASE_URL);
  }

  getLocationFromGoogle(locationName: string): Observable<any>{
    return this.http.get<any>(`${this.GOOGLE_MAPS_URL}${locationName}`)
  }


}
