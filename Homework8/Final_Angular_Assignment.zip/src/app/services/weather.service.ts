import {Injectable} from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Observable} from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class WeatherService {
  private apiKey: string = 'OkD8KkNPKQaRr9fVCXGhIo8JtWIYEF6J';
  private timezone: string = 'America/Los_Angeles';
  private units: string = 'imperial';
  private fields: string = "temperature,temperatureApparent,temperatureMin,temperatureMax,windSpeed,windDirection,humidity,pressureSeaLevel,uvIndex,weatherCode,precipitationProbability,precipitationType,sunriseTime,sunsetTime,visibility,moonPhase,cloudCover";
  private location: string;
  private BASE_WEATHER_URL: string;
  constructor(private http: HttpClient) {

  }

  getWeatherData(currentLocation:string): Observable<any>{
    this.location = currentLocation;
    console.log("'===================")
    console.log(this.location);
    this.BASE_WEATHER_URL = `https://api.tomorrow.io/v4/timelines?location=${this.location}&fields=${this.fields}&timesteps=1d&units=${this.units}&timezone=${this.timezone}&apikey=${this.apiKey}`
    return this.http.get<any>(this.BASE_WEATHER_URL);
  }
}
