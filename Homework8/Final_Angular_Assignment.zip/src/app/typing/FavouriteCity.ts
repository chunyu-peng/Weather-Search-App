export interface FavouriteCity{
  id: number,
  city: string;
  state?: string;
}
