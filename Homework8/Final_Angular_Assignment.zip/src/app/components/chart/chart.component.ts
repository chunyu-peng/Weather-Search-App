import {Component, Input, OnInit} from '@angular/core';
import { ChartType } from 'chart.js';
import * as Highcharts from "highcharts";
import HC_more from 'highcharts/highcharts-more';
HC_more(Highcharts);

@Component({
  selector: 'app-chart',
  templateUrl: './chart.component.html',
  styleUrls: ['./chart.component.css']
})
export class ChartComponent implements OnInit {
  @Input() weatherData: any;
  data: any[] = [];
  isHighcharts = typeof Highcharts === 'object';
  Highcharts: typeof Highcharts = Highcharts; // required
  chartConstructor: string = 'chart'; // optional string, defaults to 'chart'
  chartOptions: Highcharts.Options = {
    series: [{
      data: this.data,
      type: 'arearange',
      name: "Temperatures"
    }],
    title: {
      text: 'Temperature variation by day'
    },
    xAxis: {
      type: 'datetime',
      accessibility: {
        rangeDescription: 'Range: Jan 1st 2017 to Dec 31 2022.'
      }
    },
    yAxis: {
      title: {
        text: null
      }
    },
    // colors:["#ffe763", "#ededed"],

    tooltip: {
      // @ts-ignore
      crosshairs: true,
      shared: true,
      valueSuffix: '°C',
      xDateFormat: '%A, %b %e'
    },

    legend: {
      enabled: false
    },
  }; // required
  chartCallback: Highcharts.ChartCallbackFunction = function (chart) {} // optional function, defaults to null
  updateFlag: boolean = false; // optional boolean
  oneToOneFlag: boolean = true; // optional boolean, defaults to false
  runOutsideAngularFlag: boolean = false; // optional boolean, defaults to false
  constructor() { }

  ngOnInit(): void {
    //@ts-ignore
    const weatherData = JSON.parse(localStorage.getItem("weatherData"))

    const weather = weatherData.data.timelines[0].intervals
    for(let i=0; i< weather.length; i++){
      let arr = [Date.parse(weather[i].startTime.substr(0,19)), weather[i].values.temperatureMin,weather[i].values.temperatureMax];
      this.data.push(arr);
    }
    console.log(this.data)
  }


}
