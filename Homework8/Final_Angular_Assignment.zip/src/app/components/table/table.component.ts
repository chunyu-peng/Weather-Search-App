import {Component, Input, OnInit} from '@angular/core';
import {StateService} from "../../services/state.service";
import {Router} from "@angular/router";

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.css']
})
export class TableComponent implements OnInit {
  @Input() weatherData: any;
  weatherIntervals: any;

  constructor(private stateService: StateService,private router: Router) { }

  ngOnInit(): void {
    if(localStorage.getItem("weatherData")){
      // @ts-ignore
      this.weatherData = JSON.parse(localStorage.getItem("weatherData"))
    }
    this.weatherIntervals = this.weatherData.data.timelines[0].intervals

  }

  goToDetail(indexOfelement: number): void{
    this.stateService.data = this.weatherIntervals[indexOfelement];
    localStorage.setItem("weather", JSON.stringify(this.stateService.data ))
    this.router.navigate(['/detail']);
  }

  renderImage(code: number) {
    let picture: string;
    let text: string;
    if (code === 4201) {
      picture = "rain_heavy.svg"
      text = "Heavy Rain";
    }
    else if (code === 4001) {
      picture = "rain.svg";
      text = "Rain";
    }
    else if (code === 4200) {
      picture = "rain_light.svg";
      text = "Light Rain";
    }
    else if (code === 6201) {
      picture = "freezing_rain_heavy.svg";
      text = "Heavy Freezing Rain";
    }
    else if (code === 6001) {
      picture = "freezing_rain.svg";
      text = "Freezing Rain";
    }
    else if (code === 6200) {
      picture = "freezing_rain_light.svg";
      text = "Light Freezing Rain";
    }
    else if (code === 6000) {
      picture = "freezing_drizzle.svg";
      text = "Freezing Drizzle";
    }
    else if (code === 4000) {
      picture = "drizzle.svg";
      text = "Drizzle";
    }
    else if (code === 7101) {
      picture = "ice_pellets_heavy.svg";
      text = "Heavy Ice Pellets";
    }
    else if (code === 7000) {
      picture = "ice_pellets.svg";
      text = "Ice Pellets";
    }
    else if (code === 7102) {
      picture = "ice_pellets_light.svg";
      text = "Light Ice Pellets";
    }
    else if (code === 5101) {
      picture = "snow_heavy.svg";
      text = "Heavy Snow";
    }
    else if (code === 5000) {
      picture = "snow.svg";
      text = "Snow";
    }
    else if (code === 5100) {
      picture = "snow_light.svg";
      text = "Light Snow";
    }
    else if (code === 5001) {
      picture = "flurries.svg";
      text = "Flurries";
    }
    else if (code === 8000) {
      picture = "tstorm.svg";
      text = "Thunderstorm";
    }
    else if (code === 2100) {
      picture = "fog_light.svg";
      text = "Light Fog";
    }
    else if (code === 2000) {
      picture = "fog.svg";
      text = "Fog";
    }
    else if (code === 1001) {
      picture = "cloudy.svg";
      text = "Cloudy";
    }
    else if (code === 1102) {
      picture = "mostly_cloudy.svg";
      text = "Mostly Cloudy";
    }
    else if (code === 1101) {
      picture = "partly_cloudy_day.svg";
      text = "Partly Cloudy";
    }
    else if (code === 1100) {
      picture = "mostly_clear_day.svg";
      text = "Mostly Clear";
    }
    else if (code === 1000) {
      picture = "clear_day.svg";
      text = "Clear";
    }
    else if (code === 3000) {
      picture = "light_wind.svg";
      text = "Light Wind";
    }
    else if (code === 3001) {
      picture = "wind.svg";
      text = "Wind";
    }
    else if (code === 3002) {
      picture = "strong_wind.svg";
      text = "Strong Wind";
    }else{
      picture = "strong_wind.svg";
      text = "Strong Wind";
    }

    return `<img src="assets/images/${picture}" alt=""  width="40px" height="40px"/><span>${text}</span>`
  }

  renderDateString(dateString: string){
    return new Date(new Date(dateString));
  }
}


