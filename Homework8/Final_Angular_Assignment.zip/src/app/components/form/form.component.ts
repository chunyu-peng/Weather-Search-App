import {Component, OnInit, Output, EventEmitter} from '@angular/core';
import {faSearch, faAlignCenter} from '@fortawesome/free-solid-svg-icons';
import {Router} from "@angular/router";
import {FormControl} from "@angular/forms";
import {Observable} from "rxjs";

import {startWith, map} from 'rxjs/operators';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css']
})
export class FormComponent implements OnInit {
  faSearch = faSearch;
  faAlignCenter = faAlignCenter;
  inputDisabled: boolean = false;
  street: string;
  city: string;
  state: string;
  autodetect: boolean;
  streetError: string;
  cityError: string;
  btnDisabled: boolean;

  control = new FormControl();
  streets: string[] = ['Champs-Élysées', 'Lombard Street', 'Abbey Road', 'Fifth Avenue'];
  filteredStreets: Observable<string[]>;


  @Output() onLocationCheck = new EventEmitter();
  @Output() onFetchData = new EventEmitter();
  @Output() onFormSubmit = new EventEmitter();
  @Output() onFavAdd = new EventEmitter();
  @Output() onClearForm = new EventEmitter();

  title = 'Homework';
  userAddress: string = ''
  userLatitude: string = ''
  userLongitude: string = ''


  handleAddressChange(address: any) {
    this.userAddress = address.formatted_address
    this.city = address.address_components[0].long_name;
    this.userLatitude = address.geometry.location.lat()
    this.userLongitude = address.geometry.location.lng()
  }


  constructor(private router: Router) {
  }

  ngOnInit(): void {
    let retrivedForm;
    if(localStorage.getItem("formFields")){
      // @ts-ignore
      retrivedForm = JSON.parse(localStorage.getItem("formFields"));
      this.street = retrivedForm.street;
      this.city = retrivedForm.city;
      this.state = retrivedForm.state;
      this.inputDisabled = retrivedForm.inputDisabled;
      this.autodetect = retrivedForm.autodetect;
    }

    if(!this.street || !this.city){
      this.btnDisabled = true;
    }

    this.filteredStreets = this.control.valueChanges.pipe(
      startWith(''),
      map(value => this._filter(value))
    );

  }

  validateField(field: any): boolean{
    if(!field){
      return false
    }
    return true;
  }

  setSelectedState(state: string): string{
    if(state == this.state){
      return "selected"
    }
    return ""
  }


  formOnSubmit() {
    let formValid = true;
    if(!this.validateField(this.street)){
      this.streetError = "Please enter a valid street name";
      formValid = false
    }
    if(!this.validateField(this.city)){
      this.cityError = "Please enter a valid city";
      formValid = false
    }
    if(this.autodetect){
      formValid = true
    }
    if(!formValid){
      return;
    }
    this.streetError = "";
    this.cityError = "";

    if(!this.autodetect){
      let location = `${this.street}+${this.city}+${this.state}`
      const formFields = {
        street: this.street,
        city: this.city,
        inputDisabled: this.inputDisabled,
        autodetect: this.autodetect
      }
      localStorage.setItem("formFields", JSON.stringify(formFields))
      this.onFormSubmit.emit({location})
    }
    const formFields = {
      street: this.street,
      city: this.city,
      state: this.state,
      inputDisabled: this.inputDisabled,
      autodetect: this.autodetect
    }
    console.log(formFields);
    localStorage.setItem("formFields", JSON.stringify(formFields))
    this.onFetchData.emit();

  }

  onClearBtn(e:any) : void{
    localStorage.removeItem("formFields");
    localStorage.removeItem("locString");
    localStorage.removeItem("weatherData");
    localStorage.removeItem("weather");
    this.router.navigate(['/']).then(r => {
      this.clearForm();
    });
    this.onClearForm.emit();
    if (window.location.pathname == "/"){
      window.location.reload();
    }
    e.preventDefault();
  }

  clearForm() {
    this.street = "";
    this.city = "";
    this.state = "";
    this.autodetect = false;
    this.streetError = "";
    this.cityError = "";
  }

  onCurrentLocationCheck() {
    this.street = "";
    this.city = "";
    this.state = "";
    this.streetError = "";
    this.cityError = "";
    this.inputDisabled = !this.inputDisabled
    this.btnDisabled = false;
    this.onLocationCheck.emit();
    // this.onFetchData.emit();
  }

  cityValChange() {
    if(this.city && this.street){
      this.btnDisabled = false
    }
    if(this.city){
      this.cityError = "";
    }
  }

  streetValChange() {
    if(this.city && this.street){
      this.btnDisabled = false
    }
    if(this.street){
      this.streetError = "";
    }
  }
  private _filter(value: string): string[] {
    const filterValue = this._normalizeValue(value);
    return this.streets.filter(street => this._normalizeValue(street).includes(filterValue));
  }

  private _normalizeValue(value: string): string {
    return value.toLowerCase().replace(/\s/g, '');
  }
}
