import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BtnsBarComponent } from './btns-bar.component';

describe('BtnsBarComponent', () => {
  let component: BtnsBarComponent;
  let fixture: ComponentFixture<BtnsBarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BtnsBarComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BtnsBarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
