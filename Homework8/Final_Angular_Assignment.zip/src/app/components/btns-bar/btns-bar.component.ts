import {Component, OnInit, Output, EventEmitter} from '@angular/core';

@Component({
  selector: 'app-btns-bar',
  templateUrl: './btns-bar.component.html',
  styleUrls: ['./btns-bar.component.css']
})
export class BtnsBarComponent implements OnInit {

  @Output() onContextChange = new EventEmitter();
  activeIndex: number = 0;

  constructor() { }

  ngOnInit(): void {
  }

  onBtnClick(number: number) {
    this.activeIndex = number;
    this.onContextChange.emit();
  }
}
