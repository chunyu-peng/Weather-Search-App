import { Component, OnInit } from '@angular/core';
import * as Highcharts from "highcharts";
import HC_more from 'highcharts/highcharts-more';
HC_more(Highcharts);


@Component({
  selector: 'app-meteogram',
  templateUrl: './meteogram.component.html',
  styleUrls: ['./meteogram.component.css']
})

export class MeteogramComponent implements OnInit {
  minTemp: any = [];
  locString = localStorage.getItem("locString")?.toString();
  maxTemp: any = [];
  dataLabels: any = [];
  isHighcharts = typeof Highcharts === 'object';
  Highcharts: typeof Highcharts = Highcharts; // required
  chartConstructor: string = 'chart'; // optional string, defaults to 'chart'
  // @ts-ignore
  chartOptions: Highcharts.Options = {
    chart: {
      zoomType: 'x',
      panKey: 'shift'
    },
    title: {
      text: `Temperature of `+this.locString
    },
    series: [{
      type: 'line',
      data: this.minTemp,
      lineWidth: 5.0,
      name: "Minimum Temperature"
    },{
      type: 'line',
      data: this.maxTemp,
      lineWidth: 5.0,
      name: "Maximum Temperature"
    }],
    yAxis: {
      title: {
        text: 'Temperature (F)'
      }
    },
    colors:["#ff0000", "#00ff00"],
    legend: {
      layout: 'vertical',
      align: 'right',
      verticalAlign: 'middle'
    },


  }; // required
  chartCallback: Highcharts.ChartCallbackFunction = function (chart) {} // optional function, defaults to null
  updateFlag: boolean = false; // optional boolean
  oneToOneFlag: boolean = true; // optional boolean, defaults to false
  runOutsideAngularFlag: boolean = false; // optional boolean, defaults to false
  constructor() { }

  ngOnInit(): void {
    //@ts-ignore
    const weatherData = JSON.parse(localStorage.getItem("weatherData"))

    const weather = weatherData.data.timelines[0].intervals
    for(let i=0; i< weather.length; i++){
      this.dataLabels.push(weather[i].startTime);
      this.maxTemp.push([weather[i].startTime,Math.round(weather[i].values.temperatureMax)]);
      this.minTemp.push([weather[i].startTime, Math.round(weather[i].values.temperatureMin)]);
    }
    // console.log(this.data)
  }


}
