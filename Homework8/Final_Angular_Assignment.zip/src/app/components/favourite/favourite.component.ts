import {Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { faTrashAlt } from "@fortawesome/free-solid-svg-icons";
import {FavouriteCity} from "../../typing/FavouriteCity";

@Component({
  selector: 'app-favourite',
  templateUrl: './favourite.component.html',
  styleUrls: ['./favourite.component.css']
})
export class FavouriteComponent implements OnInit {
  faTrashAlt = faTrashAlt;
  locString: string;

  @Input() favourites: FavouriteCity[];
  @Output() onDeleteClick = new EventEmitter();

  constructor() { }

  ngOnInit(): void {
    if(localStorage.getItem("locString")){
      // @ts-ignore
      this.locString = JSON.parse(localStorage.getItem("locString"));
    }
  }
  deleteFavourite(id: number){
    this.onDeleteClick.emit({id: id})
    window.location.reload();
  }

}
