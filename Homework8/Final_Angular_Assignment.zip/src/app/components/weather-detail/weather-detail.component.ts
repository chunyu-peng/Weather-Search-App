import {Component, Input, OnInit} from '@angular/core';
import {faTwitter} from '@fortawesome/free-brands-svg-icons';
import {faChevronLeft} from '@fortawesome/free-solid-svg-icons';

import {LocationService} from "../../services/location.service";
import {WeatherService} from "../../services/weather.service";
import {StateService} from "../../services/state.service";

@Component({
  selector: 'app-weather-detail',
  templateUrl: './weather-detail.component.html',
  styleUrls: ['./weather-detail.component.css']
})
export class WeatherDetailComponent implements OnInit {
  private currentlocation: string;
  weatherData: any = {}
  twitterString: string = ""
  locString: string;
  faLeft = faChevronLeft;

  @Input() weather?: any;
  data: any[];

  constructor(private currentLocationService: LocationService, private weatherService: WeatherService, private stateService: StateService) {
  }

  ngOnInit(): void {
    this.weather = this.stateService?.data;
    if (localStorage.getItem("weather")) {
      // @ts-ignore
      this.weather = JSON.parse(localStorage.getItem("weather"));
    }
    if (localStorage.getItem("locString")) {
      // @ts-ignore
      this.locString = JSON.parse(localStorage.getItem("locString"));
    }

  }

  convertToDateString(dateString: string) {
    return new Date(new Date(dateString)).toString().substr(0, 15);
  }

  fetchCurrentLocation() {
    this.currentLocationService.getLocation().subscribe((loc) => {
      this.currentlocation = loc.loc.toString();
      this.fetchWeatherLocation();
    });
  }

  fetchWeatherLocation() {
    this.weatherService.getWeatherData(this.currentlocation).subscribe((weather) => {
      this.weatherData = weather;
      console.log(weather);
    });
  }

  composeTwitterString() {
    return `The temperature in ${this.locString} on ${new Date(new Date(this.weather.startTime)).toString().substr(0,15)} is ${this.weather.values.temperatureApparent}°F.The weather conditions are ${this.renderStatus(this.weather.values.weatherCode)}`
  }

  renderStatus(code: number) {
    let text: string;
    if (code === 4201) {
      text = "Heavy Rain";
    } else if (code === 4001) {
      text = "Rain";
    } else if (code === 4200) {
      text = "Light Rain";
    } else if (code === 6201) {
      text = "Heavy Freezing Rain";
    } else if (code === 6001) {
      text = "Freezing Rain";
    } else if (code === 6200) {
      text = "Light Freezing Rain";
    } else if (code === 6000) {
      text = "Freezing Drizzle";
    } else if (code === 4000) {
      text = "Drizzle";
    } else if (code === 7101) {
      text = "Heavy Ice Pellets";
    } else if (code === 7000) {
      text = "Ice Pellets";
    } else if (code === 7102) {
      text = "Light Ice Pellets";
    } else if (code === 5101) {
      text = "Heavy Snow";
    } else if (code === 5000) {
      text = "Snow";
    } else if (code === 5100) {
      text = "Light Snow";
    } else if (code === 5001) {
      text = "Flurries";
    } else if (code === 8000) {
      text = "Thunderstorm";
    } else if (code === 2100) {
      text = "Light Fog";
    } else if (code === 2000) {
      text = "Fog";
    } else if (code === 1001) {
      text = "Cloudy";
    } else if (code === 1102) {
      text = "Mostly Cloudy";
    } else if (code === 1101) {
      text = "Partly Cloudy";
    } else if (code === 1100) {
      text = "Mostly Clear";
    } else if (code === 1000) {
      text = "Clear";
    } else if (code === 3000) {
      text = "Light Wind";
    } else if (code === 3001) {
      text = "Wind";
    } else if (code === 3002) {
      text = "Strong Wind";
    } else {
      text = "Strong Wind";
    }

    return text;
  }
}
