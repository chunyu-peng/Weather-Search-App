import {Component, OnInit,NgZone} from '@angular/core';
import {LocationService} from "../../services/location.service";
import {WeatherService} from "../../services/weather.service";
import { faStar, faChevronRight} from "@fortawesome/free-solid-svg-icons";
import {FavouriteCity} from "../../typing/FavouriteCity";

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css']
})
export class MainComponent implements OnInit {
  private enteredLocation: string;
  weatherData: any;
  locString: string;
  isLoading: boolean = false;
  isFavouriteActive = false;
  favouriteList: FavouriteCity[] = [];
  faStar = faStar;
  faChevronRight = faChevronRight;

  private city: string;
  private state: string;
  id: number;
  address: Object;
  establishmentAddress: Object;

  formattedAddress: string;
  formattedEstablishmentAddress: string;

  phone: string;


  // @ts-ignore
  getAddress(place: object) {
    // @ts-ignore
    this.address = place['formatted_address'];
    this.phone = this.getPhone(place);
    // @ts-ignore
    this.formattedAddress = place['formatted_address'];
    // @ts-ignore
    this.zone.run(() => this.formattedAddress = place['formatted_address']);
  }

  getEstablishmentAddress(place: object) {

    // @ts-ignore
    this.establishmentAddress = place['formatted_address'];
    this.phone = this.getPhone(place);

    // @ts-ignore
    this.formattedEstablishmentAddress = place['formatted_address'];
    this.zone.run(() => {

      // @ts-ignore
      this.formattedEstablishmentAddress = place['formatted_address'];

      // @ts-ignore
      this.phone = place['formatted_phone_number'];
    });
  }


  // @ts-ignore
  getAddrComponent(place, componentTemplate) {
    let result;

    for (let i = 0; i < place.address_components.length; i++) {
      const addressType = place.address_components[i].types[0];
      if (componentTemplate[addressType]) {
        result = place.address_components[i][componentTemplate[addressType]];
        return result;
      }
    }
    return;
  }

  getStreetNumber(place: any) {
    const COMPONENT_TEMPLATE = { street_number: 'short_name' },
      streetNumber = this.getAddrComponent(place, COMPONENT_TEMPLATE);
    return streetNumber;
  }

  getStreet(place: any) {
    const COMPONENT_TEMPLATE = { route: 'long_name' },
      street = this.getAddrComponent(place, COMPONENT_TEMPLATE);
    return street;
  }

  getCity(place:any) {
    const COMPONENT_TEMPLATE = { locality: 'long_name' },
      city = this.getAddrComponent(place, COMPONENT_TEMPLATE);
    return city;
  }

  getState(place: any) {
    const COMPONENT_TEMPLATE = { administrative_area_level_1: 'short_name' },
      state = this.getAddrComponent(place, COMPONENT_TEMPLATE);
    return state;
  }

  getDistrict(place:any) {
    const COMPONENT_TEMPLATE = { administrative_area_level_2: 'short_name' },
      state = this.getAddrComponent(place, COMPONENT_TEMPLATE);
    return state;
  }

  getCountryShort(place: any) {
    const COMPONENT_TEMPLATE = { country: 'short_name' },
      countryShort = this.getAddrComponent(place, COMPONENT_TEMPLATE);
    return countryShort;
  }

  getCountry(place: any) {
    const COMPONENT_TEMPLATE = { country: 'long_name' },
      country = this.getAddrComponent(place, COMPONENT_TEMPLATE);
    return country;
  }

  getPostCode(place: any) {
    const COMPONENT_TEMPLATE = { postal_code: 'long_name' },
      postCode = this.getAddrComponent(place, COMPONENT_TEMPLATE);
    return postCode;
  }

  getPhone(place: any) {
    const COMPONENT_TEMPLATE = { formatted_phone_number: 'formatted_phone_number' },
      phone = this.getAddrComponent(place, COMPONENT_TEMPLATE);
    return phone;
  }

  constructor(private currentLocationService: LocationService, private weatherService: WeatherService,public zone: NgZone) {
  }

  ngOnInit(): void {
    if (localStorage.getItem("weatherData")){
      // @ts-ignore
      this.weatherData = JSON.parse(localStorage.getItem("weatherData"));
    }
    if (localStorage.getItem("favouriteList")){
      // @ts-ignore
      this.favouriteList = JSON.parse(localStorage.getItem("favouriteList"));
    }
    if (localStorage.getItem("locString")){
      // @ts-ignore
      this.locString = JSON.parse(localStorage.getItem("locString"));
    }
  }

  fetchCurrentLocation() {
    this.currentLocationService.getLocation().subscribe((loc) => {
      this.enteredLocation = loc.loc.toString();
      this.city = loc.city;
      this.state = loc.country;
      this.locString = `${this.city}, ${this.state}`;
      localStorage.setItem("locString",JSON.stringify(this.locString));
    });
  }

  addToFavourite(){

    const city = {
      id: this.favouriteList.length,
      city: this.city,
      state: this.state
    }
    this.favouriteList.push(city);
    localStorage.setItem("favouriteList", JSON.stringify(this.favouriteList))
  }

  removeFromFavourite(value: any){
    console.log("ID: "+ value.id );
    const lists = this.favouriteList.filter((city)=> city.id != value.id);
    localStorage.setItem("favouriteList", JSON.stringify(lists))
    console.log(lists);
  }

  fetchLocationFromGoogle(value:any){
    this.isLoading = true;
    this.currentLocationService.getLocationFromGoogle(value.location).subscribe((result) => {
      this.locString = result.results[0].formatted_address;
      localStorage.setItem("locString", JSON.stringify(this.locString));
      this.city = result.results[0].address_components[1].short_name;
      this.state = result.results[0].address_components[2].long_name;
      this.enteredLocation = `${result.results[0].geometry.location.lat},${result.results[0].geometry.location.lng}`;
      this.fetchWeatherLocation();
      this.isLoading = false;
    })
  }

  fetchWeatherLocation() {
    if(this.enteredLocation){
      this.weatherService.getWeatherData(this.enteredLocation).subscribe((weather) => {
        this.weatherData = weather;
        localStorage.setItem("weatherData", JSON.stringify(weather))
        console.log(weather);
      });
    }

  }

  switchTabs(): void {
    this.isFavouriteActive = !this.isFavouriteActive;
  }

  clearData() {
    localStorage.removeItem("locString");
    localStorage.removeItem("weatherData")
  }
}
