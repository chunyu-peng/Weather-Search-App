import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-tabs',
  templateUrl: './tabs.component.html',
  styleUrls: ['./tabs.component.css']
})
export class TabsComponent implements OnInit {
  activeTab: number = 0;

  @Input() data: any;

  constructor() { }

  ngOnInit(): void {
  }

  setActiveTab(number: number) {
    this.activeTab= number;
  }
}
