import {NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {HttpClientModule} from "@angular/common/http";

import {AppComponent} from './app.component';
import {FormComponent} from './components/form/form.component';
import {HeaderComponent} from './components/header/header.component';
import {FontAwesomeModule} from '@fortawesome/angular-fontawesome';
import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import {BtnsBarComponent} from './components/btns-bar/btns-bar.component';
import {ProgressBarComponent} from './components/progress-bar/progress-bar.component';
import {TabsComponent} from './components/tabs/tabs.component';
import { MainComponent } from './components/main/main.component';
import { TableComponent } from './components/table/table.component';
import {RouterModule, Routes} from "@angular/router";
import { ChartComponent } from './components/chart/chart.component';
import { MeteogramComponent } from './components/meteogram/meteogram.component';

import { ChartsModule } from 'ng2-charts';
import {WeatherDetailComponent} from "./components/weather-detail/weather-detail.component";
import { MapComponent } from './components/map/map.component';
import {GoogleMapsModule} from "@angular/google-maps";
import { FavouriteComponent } from './components/favourite/favourite.component';
import {HighchartsChartModule} from "highcharts-angular";
import { TweetComponent } from './components/tweet/tweet.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {GooglePlaceModule} from "ngx-google-places-autocomplete";

const appRoutes: Routes = [
  { path: '', component: MainComponent },
  { path: 'detail', component: WeatherDetailComponent }
];

@NgModule({
  declarations: [
    AppComponent,
    FormComponent,
    HeaderComponent,
    BtnsBarComponent,
    ProgressBarComponent,
    TabsComponent,
    MainComponent,
    TableComponent,
    ChartComponent,
    MeteogramComponent,
    WeatherDetailComponent,
    MapComponent,
    FavouriteComponent,
    TweetComponent
  ],
  imports: [
    BrowserModule,
    FontAwesomeModule,
    FormsModule,
    HttpClientModule,
    RouterModule,
    ChartsModule,
    GoogleMapsModule,
    RouterModule.forRoot(appRoutes),
    HighchartsChartModule,
    BrowserAnimationsModule,
    GooglePlaceModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {
}
