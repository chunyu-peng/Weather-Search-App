const express = require('express');
const bodyParser = require('body-parser')

var request = require('request');

const app = express();
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// VARIABLES
const apiKey = 'OkD8KkNPKQaRr9fVCXGhIo8JtWIYEF6J';
const timezone = 'America/Los_Angeles';
const units = 'imperial';
const fields = "temperature,temperatureApparent,temperatureMin,temperatureMax,windSpeed,windDirection,humidity,pressureSeaLevel,uvIndex,weatherCode,precipitationProbability,precipitationType,sunriseTime,sunsetTime,visibility,moonPhase,cloudCover";


app.get("/", async (req, res)=> {
  const location = req.query.loc
  const url = `https://api.tomorrow.io/v4/timelines?location=${location}&fields=${fields}&timesteps=1d&units=${units}&timezone=${timezone}&apikey=${apiKey}`;
  request({
    uri: url,
  }).pipe(res);
});

const PORT = process.env.PORT || 3000
app.listen(PORT, ()=> {
  console.log("App running on PORT:"+PORT)
});
